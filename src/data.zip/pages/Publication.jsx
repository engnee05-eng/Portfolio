import { ArrowSquareOut, BookOpen, Globe } from '@phosphor-icons/react';
import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import SectionHeader from '../components/ui/SectionHeader';
import { cvData } from '../data/cvData';

const PublicationCard = ({ pub }) => {
    if (!pub) return null;

    return (
        <article className="scholarly-tile group tile-aura-journal">
            <div className="scholarly-tile-header">
                <span className="scholarly-tile-pill bg-blue-50 text-blue-600 border border-blue-100">
                    {pub.subType || 'Journal Article'}
                </span>
                <span className="scholarly-tile-meta">{pub.year || '2023'}</span>
            </div>

            <h3 className="scholarly-tile-title">
                {pub.title}
            </h3>

            <p className="scholarly-tile-desc leading-relaxed">
                {pub.authors}
            </p>

            <div className="scholarly-tile-footer">
                <span className="scholarly-tile-tag flex items-center gap-2 max-w-full">
                    <Globe size={14} className="text-[var(--accent)] shrink-0" />
                    <span>{pub.journal || pub.venue || 'International'}</span>
                </span>
                {pub.citations > 0 && (
                    <span className="scholarly-tile-tag !text-amber-600 !border-amber-200">
                        {pub.citations} Citations
                    </span>
                )}
            </div>
        </article>
    );
};

export default function Publication() {
    useEffect(() => {
        document.title = 'Publications | Dr. Sumegh S. Tharewal';
        window.scrollTo(0, 0);
    }, []);

    const publications = cvData.publications || [];
    const books = cvData.books || [];

    return (
        <div className="page-wrap bg-slate-50/30">
            <div className="container space-y-12 py-10">
                <header className="max-w-4xl mx-auto text-center space-y-4">
                    <div className="flex justify-center">
                        <div className="glass-panel p-2 px-3 flex items-center gap-4 border border-slate-100 shadow-xl scale-95">
                            <div className="flex -space-x-1">
                                {[1, 2, 3].map((i) => (
                                    <div key={i} className="w-6 h-6 rounded-full border-2 border-white bg-gradient-to-br from-[var(--accent)] to-[var(--accent-secondary)]" />
                                ))}
                            </div>
                            <div className="text-left pr-3 border-l border-slate-100 pl-4">
                                <div className="text-[12px] font-black uppercase tracking-[0.2em] text-slate-400 mb-0.5">Scholarly Impact</div>
                                <div className="text-sm font-black text-slate-900 tracking-tight">746+ Citations</div>
                            </div>
                        </div>
                    </div>
                    <div className="space-y-2 items-start w-fit mx-auto">
                        <span className="section-kicker mx-auto">Peer-Reviewed Corpus</span>
                        <h1 className="page-title text-4xl md:text-5xl font-black tracking-tight">Scholarly Contributions</h1>
                        <p className="page-lead mx-auto max-w-2xl text-base text-slate-500 font-medium">A high-density archive of authored volumes and high-impact journal articles published globally.</p>
                    </div>
                </header>

                <section className="grid grid-cols-4 gap-4 w-full !flex-row publications-summary-grid">                    <div className="card-modern p-5 flex flex-col justify-center text-center bg-white border border-slate-100 shadow-sm">
                    <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 mb-1">Published books</span>
                    <strong className="text-3xl font-black text-slate-900 leading-none">{books.length}</strong>
                </div>
                    <div className="card-modern p-5 flex flex-col justify-center text-center bg-white border border-slate-100 shadow-sm">
                        <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 mb-1">Journal papers</span>
                        <strong className="text-3xl font-black text-slate-900 leading-none">{publications.length}+</strong>
                    </div>
                    <div className="card-modern p-5 flex flex-col justify-center text-center bg-white border border-slate-100 shadow-sm">
                        <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 mb-1">Scholarly reach</span>
                        <strong className="text-3xl font-black text-[var(--accent)] leading-none">746+</strong>
                    </div>
                    <div className="card-modern p-5 flex flex-col justify-center text-center bg-white border border-slate-100 shadow-sm">
                        <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 mb-1">ResearchGate Reads</span>
                        <strong className="text-3xl font-black text-[var(--accent)] leading-none">53k+</strong>
                    </div>
                </section>

                {books.length > 0 && (
                    <section className="section-shell">
                        <div className="section-header-compact">
                            <SectionHeader title="Authored & Edited Books" subtitle="Published scholarly volumes covering CS foundations." centered={false} />
                        </div>
                        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-5 xl:grid-cols-5 gap-4">
                            {books.map((book, idx) => (
                                <a key={idx} href={book.amazonLink} target="_blank" rel="noopener noreferrer" className="group block">
                                    <div className="aspect-[3/3.7] rounded-xl bg-white shadow-md overflow-hidden mb-3 group-hover:shadow-2xl transition-all border border-slate-100">
                                        {book.image ? (
                                            <img src={book.image} alt={book.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                                        ) : (
                                            <div className="w-full h-full bg-slate-50 flex items-center justify-center">
                                                <BookOpen size={24} weight="duotone" className="text-slate-300" />
                                            </div>
                                        )}
                                    </div>
                                </a>
                            ))}
                        </div>
                    </section>
                )}

                <section className="section-shell">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 px-2">
                        <SectionHeader title="Principal Journal Papers" subtitle="Peer-reviewed articles in high-impact journals." centered={false} />
                        <Link to="/archive?tab=journals" className="btn-secondary group shrink-0 btn-compact !text-base !px-5 text-slate-900 border-slate-200">
                            Full Journal Archive <ArrowSquareOut size={20} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                        </Link>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                        {publications.slice(0, 8).map((pub, idx) => (
                            <PublicationCard key={idx} pub={pub} />
                        ))}
                    </div>
                </section>
            </div>
        </div>
    );
}
