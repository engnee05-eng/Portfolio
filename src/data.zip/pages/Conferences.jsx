import { ArrowSquareOut, Calendar, Globe, MapPin } from '@phosphor-icons/react';
import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import SectionHeader from '../components/ui/SectionHeader';
import { cvData } from '../data/cvData';

const ConferenceCard = ({ conf }) => {
    if (!conf) return null;

    return (
        <article className="scholarly-tile group tile-aura-conference">
            <div className="scholarly-tile-header">
                <span className={`scholarly-tile-pill ${conf.subType === 'International' ? 'bg-amber-50 text-amber-600 border-amber-100' : 'bg-slate-50 text-slate-500 border-slate-100'}`}>
                    {conf.subType || 'International'}
                </span>
                <div className="flex items-center gap-1.5 scholarly-tile-meta">
                    <Calendar size={13} weight="bold" />
                    {conf.year}
                </div>
            </div>

            <h3 className="scholarly-tile-title italic">
                "{conf.title}"
            </h3>

            <p className="scholarly-tile-desc leading-relaxed">
                {conf.authors}
            </p>

            <div className="scholarly-tile-footer">
                <span className="scholarly-tile-tag flex items-center gap-2 max-w-full">
                    <Globe size={14} className="text-amber-500 shrink-0" weight="duotone" />
                    <span>{conf.venue}</span>
                </span>
                {conf.location && (
                    <span className="scholarly-tile-tag flex items-center gap-2">
                        <MapPin size={14} className="text-slate-400" />
                        {conf.location}
                    </span>
                )}
            </div>
        </article>
    );
};

export default function Conferences() {
    useEffect(() => {
        document.title = 'Conferences | Dr. Sumegh S. Tharewal';
        window.scrollTo(0, 0);
    }, []);

    const { conferences } = cvData;
    const international = (conferences || []).filter((c) => c.subType === 'International');
    const national = (conferences || []).filter((c) => c.subType === 'National');

    return (
        <div className="page-wrap bg-slate-50/20">
            <div className="container space-y-12 py-10">
                <header className="max-w-4xl mx-auto text-center space-y-4">
                    <div className="flex justify-center">
                        <div className="glass-panel p-2 px-3 flex items-center gap-4 border border-slate-100 shadow-xl scale-95">
                            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white">
                                <Globe size={20} weight="duotone" />
                            </div>
                            <div className="text-left pr-3 border-l border-slate-100 pl-4">
                                <div className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-0.5">Global Presence</div>
                                <div className="text-md font-black text-slate-900 tracking-tight">{conferences.length} Proceedings</div>
                            </div>
                        </div>
                    </div>
                    <div className="space-y-2 items-start w-fit mx-auto">
                        <span className="section-kicker mx-auto">Scholarly Proceedings</span>
                        <h1 className="page-title text-4xl md:text-5xl font-black leading-tight tracking-tight">Research Dissemination</h1>
                        <p className="page-lead mx-auto max-w-2xl text-base text-slate-500 font-medium">Peer-reviewed conference proceedings presenting research at global academic forums.</p>
                    </div>
                </header>

                <section className="summary-band-compact conference-summary-strip">
                    <div className="card-modern p-5 flex flex-col justify-center text-center bg-white border border-slate-100 shadow-sm">
                        <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 mb-1">International</span>
                        <strong className="text-3xl font-black text-amber-600 leading-none">{international.length}</strong>
                    </div>
                    <div className="card-modern p-5 flex flex-col justify-center text-center bg-white border border-slate-100 shadow-sm">
                        <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 mb-1">National</span>
                        <strong className="text-3xl font-black text-slate-500 leading-none">{national.length}</strong>
                    </div>
                    <div className="card-modern p-5 flex flex-col justify-center text-center bg-white border border-slate-100 shadow-sm">
                        <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 mb-1">Total Coverage</span>
                        <strong className="text-3xl font-black text-slate-900 leading-none">{conferences.length}</strong>
                    </div>
                </section>

                <section className="section-shell">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 px-2">
                        <SectionHeader title="International Proceedings" subtitle="Research shared across IEEE, Springer, and global venues." centered={false} />
                        <Link to="/archive?tab=conferences&filter=International" className="btn-secondary group shrink-0 btn-compact !text-base !px-5 text-slate-900 border-slate-200">
                            Full Registry <ArrowSquareOut size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                        </Link>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 md:grid-cols-4 gap-8">
                        {international.slice(0, 8).map((conf, index) => (
                            <ConferenceCard key={index} conf={conf} />
                        ))}
                    </div>
                </section>

                <section className="section-shell">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 px-2">
                        <SectionHeader title="National Proceedings" subtitle="Contributions to national scholarly symposiums and forums." centered={false} />
                        <Link to="/archive?tab=conferences&filter=National" className="btn-secondary group shrink-0 btn-compact !text-base !px-5 text-slate-900 border-slate-200">
                            Full Registry <ArrowSquareOut size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                        </Link>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 md:grid-cols-4 gap-8">
                        {national.slice(0, 8).map((conf, index) => (
                            <ConferenceCard key={index} conf={conf} />
                        ))}
                    </div>
                </section>
                <section className="bg-transparent">
                    <div className="mx-auto w-max">
                        <div className="cta-banner relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-purple-600 to-cyan-500 p-12 text-center shadow-[0_20px_50px_rgba(79,70,229,0.4)] transition-all duration-500">
                            <div className="relative h-16 w-16 mx-auto mb-1">
                                <div className="absolute inset-0 animate-ping rounded-full bg-amber-500/20" />
                                <div className="relative flex h-full w-full items-center justify-center rounded-full bg-amber-500 border border-amber-400/50 shadow-[0_0_20px_rgba(245,158,11,0.4)]">
                                    <Globe size={32} weight="fill" className="text-white" />
                                </div>
                            </div>

                            <div className="cta-layout">
                                <h4 className="text-3xl font-bold tracking-tight text-white md:text-5xl">Bridging <span className="text-amber-400">theoretical research</span> with practical innovation.</h4>
                                <p className="mt-4 text-lg font-medium text-white/90">Empowering progress through global scholarly communities.</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div >
        </div >
    );
}
