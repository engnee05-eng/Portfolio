import { useEffect } from 'react';
import { Books, GraduationCap, ArrowRight, Student, ChalkboardTeacher, ProjectorScreenChart, Certificate, MicrophoneStage, Globe, ShareNetwork, ShieldCheck, Cpu, Code, Lightbulb, UsersThree } from '@phosphor-icons/react';
import { Link } from 'react-router-dom';
import SectionHeader from '../components/ui/SectionHeader';
import { cvData } from '../data/cvData';

/* ---------------- ACADEMIC SECTION CARD ---------------- */
const GlowCard = ({ label, title, subtitle, impact, glowColor, icon: Icon }) => (
    <div className="glow-card-mentorship group h-full flex flex-col" style={{ '--glow-color': glowColor, '--glow-alpha': `${glowColor}15` }}>
        <div className="flex justify-between items-start mb-6">
            <div className="icon-box-futuristic shrink-0" style={{ '--accent': glowColor }}>
                <Icon size={24} weight="duotone" />
            </div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">{label}</span>
        </div>
        <h3 className="text-xl font-black text-slate-900 mb-2 leading-tight group-hover:text-[var(--glow-color)] transition-colors">{title}</h3>
        <p className="text-[11px] font-bold text-slate-400 mb-4 uppercase tracking-[0.1em]">{subtitle}</p>
        {impact && <p className="text-[13px] font-medium text-slate-500 mt-auto pt-4 border-t border-slate-100/80 leading-relaxed">{impact}</p>}
    </div>
);

const CourseCard = ({ course, icon: Icon, color }) => (
    <article className="glass-panel p-6 flex flex-col h-full border-t-4 hover:bg-white transition-all group" style={{ borderColor: color }}>
        <div className="flex items-center gap-4 mb-6">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-lg" style={{ background: color }}>
                <Icon size={20} weight="duotone" />
            </div>
            <h4 className="text-xl font-black text-slate-900 leading-tight">{course.category}</h4>
        </div>
        <ul className="space-y-3.5 mb-auto">
            {course.codes.map((code, i) => (
                <li key={i} className="text-base text-slate-500 font-medium flex items-start gap-3 group/item">
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-200 mt-1.5 group-hover/item:bg-[var(--accent)] transition-all" />
                    <span className="group-hover/item:text-slate-900 transition-colors">{code}</span>
                </li>
            ))}
        </ul>
    </article>
);

/* ---------------- PAGE ---------------- */
export default function Academics() {
    useEffect(() => {
        document.title = 'Pedagogical Excellence | Dr. Sumegh S. Tharewal';
        window.scrollTo(0, 0);
    }, []);

    const { academics, academicLeadership } = cvData;

    return (
        <div className="page-wrap bg-slate-50/20">
            <div className="container space-y-16 py-10">
                {/* ---------- SHARED STYLE HEADER ---------- */}
                <header className="max-w-4xl mx-auto text-center space-y-4">
                    <div className="flex justify-center">
                        <div className="glass-panel p-2 px-3 flex items-center gap-4 border border-slate-100 shadow-xl scale-95">
                            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[var(--accent)] to-[var(--accent-secondary)] flex items-center justify-center text-white">
                                <GraduationCap size={20} weight="duotone" />
                            </div>
                            <div className="text-left pr-3 border-l border-slate-100 pl-4">
                                <div className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-0.5">Expansive Tenure</div>
                                <div className="text-md font-black text-slate-900 tracking-tight">15+ Years Excellence</div>
                            </div>
                        </div>
                    </div>
                    <div className="space-y-2 items-start w-fit mx-auto">
                        <span className="section-kicker mx-auto">Institutional Gateway</span>
                        <h1 className="page-title text-4xl md:text-5xl font-black tracking-tight leading-tight">Teaching Philosophy & Academic Mentorship</h1>
                        <p className="page-lead mx-auto max-w-2xl text-base text-slate-500 font-medium">Designing future-ready curricula and fostering scholarly growth through research-led teaching and professional student guidance.</p>
                    </div>
                </header>

                <section className="section-shell pt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {academicLeadership.slice(0, 2).map((item, idx) => (
                            <div key={idx} className="glass-panel p-6 border-l-4 border-l-[var(--accent)] hover:bg-white transition-all shadow-md">
                                <h3 className="text-[17px] font-black text-slate-900 mb-3 leading-snug">{item.title.replace("paper's", "Papers")}</h3>
                                <p className="text-[14px] font-medium text-slate-500 leading-relaxed">{item.description}</p>
                            </div>
                        ))}
                    </div>
                </section>

                <section className="section-shell pt-10">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 px-2">
                        <SectionHeader title="Scholarly Guidance" subtitle="Elevating research candidates through structured mentorship and technical governance." centered={false} />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 ">
                        {academics.mentorship.map((item, idx) => {
                            const icons = [Student, ChalkboardTeacher, ProjectorScreenChart];
                            const colors = ["#7c3aed", "#0ea5e9", "#10b981"];
                            const labels = ["PHD LEVEL", "GRADUATE", "UNDERGRAD"];
                            const Icon = icons[idx % icons.length];
                            
                            // Determine subtitle based on data structure
                            let subtitle = item.metric;
                            if (item.metric === "Dissertations" || item.metric === "Guided") subtitle = item.count;
                            if (item.metric === "3 Scholars") subtitle = "8 Doctoral Scholars"; // Override to match previously preferred UI data if it exists

                            return (
                                <GlowCard
                                    key={idx}
                                    label={labels[idx % labels.length]}
                                    title={item.title}
                                    subtitle={subtitle}
                                    impact={item.impact}
                                    glowColor={colors[idx % colors.length]}
                                    icon={Icon}
                                />
                            );
                        })}
                    </div>
                </section>

                {/* ---------- ACADEMIC GOVERNANCE ---------- */}
                <section className="section-shell">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 px-2">
                        <SectionHeader title="Governance & Leadership" subtitle="Administrative and strategic roles in global academic institutions." centered={false} />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 px-1">
                        {academics.governance && academics.governance.map((item, idx) => (
                            <div key={idx} className="glass-panel p-6 border-t-4 hover:bg-white transition-all shadow-md group flex flex-col" style={{ borderColor: 'var(--accent)' }}>
                                <h3 className="text-[16px] font-black text-slate-900 mb-2 leading-tight group-hover:text-[var(--accent)] transition-colors">{item.role}</h3>
                                <p className="text-[13px] font-medium text-slate-500 mb-5 leading-relaxed">{item.institution}</p>
                                <div className="mt-auto">
                                    <span className="inline-block text-[10px] font-black uppercase tracking-widest text-[var(--accent)] bg-[var(--accent-soft)] px-2.5 py-1 rounded-md">{item.year}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>

                {/* ---------- SCHOLARLY SERVICE & TALKS ---------- */}
                <section className="section-shell">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 px-2">
                        <SectionHeader title="Academic Service & Public Pedagogy" subtitle="Global scholarly reach through peer-reviewing, keynotes, and expert lectures." centered={false} />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
                        <div className="card-modern p-8 group border-t-4 border-t-blue-500 bg-white flex flex-col">
                            <div className="flex items-center gap-4 mb-6 p-1">
                                <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600">
                                    <Globe size={24} weight="duotone" />
                                </div>
                                <div>
                                    <h3 className="text-xl font-black text-slate-900 space-y-1 p-1">Peer Review & Service</h3>
                                    <p className="text-xs font-black text-slate-400 uppercase tracking-widest leading-none mt-2 p-1 space-y-4">International Journals</p>
                                </div>
                            </div>
                            <p className="text-md text-slate-500 leading-relaxed font-medium mb-8 p-3 p-1">
                                Active reviewer and committee member for prestigious international venues including IEEE and Springer.
                            </p>
                            <div className="flex flex-wrap gap-3 p-2 text-sm mt-auto">
                                <span className="px-3 py-1.6 rounded-lg bg-blue-50/50 border border-blue-100 text-xs font-bold text-blue-700">IEEE Reviewer</span>
                                <span className="px-3 py-1.6 rounded-lg bg-emerald-50/50 border border-emerald-100 text-xs font-bold text-emerald-700">Springer Reviewer</span>
                                <span className="px-3 py-1.6 rounded-lg bg-violet-50/50 border border-violet-100 text-xs font-bold text-violet-700">Program Committee</span>
                            </div>
                        </div>

                        <div className="card-modern p-8 group border-t-4 border-t-emerald-500 bg-white flex flex-col justify-between">
                            <div>
                                <div className="flex items-center gap-4 mb-6 p-1">
                                    <div className="w-12 h-12 p-1 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600">
                                        <MicrophoneStage size={24} weight="duotone" />
                                    </div>
                                    <div>
                                        <h3 className="text-xl font-black text-slate-900 p-1">Invited Scholarly Talks</h3>
                                        <p className="text-xs font-black text-slate-400 uppercase tracking-widest leading-none mt-1 p-1">Keynotes & Expert Lectures</p>
                                    </div>
                                </div>
                                <ul className="space-y-4 px-1 mt-4">
                                    {academics.invitedTalks && academics.invitedTalks.map((talk, idx) => (
                                        <li key={idx} className="flex gap-3 items-start">
                                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0" />
                                            <div>
                                                <p className="text-[13.5px] font-bold text-slate-800 leading-tight">{talk.title}</p>
                                                <p className="text-[11.5px] font-medium text-slate-500 mt-0.5">{talk.event} &bull; {talk.year}</p>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="flex items-center gap-3 mt-8 p-2 text-sm">
                                <Link to="/archive?tab=awards" className="text-[11px] font-black uppercase tracking-widest text-[var(--accent)] flex items-center gap-2 group-hover:gap-3 transition-all">
                                    View Full Speaking Registry <ArrowRight size={14} />
                                </Link>
                            </div>
                        </div>
                    </div>
                </section>

                {/* ---------- INSTITUTIONAL INITIATIVES & WORKSHOPS ---------- */}
                <section className="section-shell">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 px-2">
                        <SectionHeader title="Initiatives & Workshops" subtitle="Driving institutional growth through organizing technical symposiums and academic alliances." centered={false} />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 px-2">Workshops Organized</h4>
                            {academics.workshopsOrganized && academics.workshopsOrganized.map((ws, idx) => (
                                <div key={idx} className="glass-panel p-5 border-l-4 border-l-[#f59e0b] hover:bg-white transition-all shadow-sm flex items-start gap-4">
                                    <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center text-orange-500 shrink-0">
                                        <UsersThree size={20} weight="duotone" />
                                    </div>
                                    <div>
                                        <h3 className="text-[14px] font-bold text-slate-900 leading-snug">{ws.title}</h3>
                                        <div className="flex items-center gap-2 mt-1.5">
                                            <span className="text-[10px] font-black uppercase tracking-widest text-orange-600 bg-orange-50 px-2 py-0.5 rounded">{ws.role}</span>
                                            <span className="text-[11px] font-bold text-slate-400">{ws.year}</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="space-y-4">
                            <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4 px-2">Strategic Initiatives</h4>
                            {academics.initiatives && academics.initiatives.map((ini, idx) => (
                                <div key={idx} className="glass-panel p-5 border-l-4 border-l-[#8b5cf6] hover:bg-white transition-all shadow-sm flex items-start gap-4">
                                    <div className="w-10 h-10 rounded-xl bg-violet-50 flex items-center justify-center text-violet-500 shrink-0">
                                        <Lightbulb size={20} weight="duotone" />
                                    </div>
                                    <div>
                                        <h3 className="text-[14px] font-bold text-slate-900 leading-snug">{ini.title}</h3>
                                        <p className="text-[12px] font-medium text-slate-500 mt-1 leading-relaxed">{ini.description}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* ---------- CURRICULUM GRID REDESIGN ---------- */}
                <section className="section-shell">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 px-2">
                        <SectionHeader title="Curriculum Development" subtitle="Master course architectures and pedagogical blueprints across diverse academic levels." centered={false} />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 px-1">
                        <CourseCard course={academics.coursesTaught[0]} icon={ShareNetwork} color="#7c3aed" />
                        <CourseCard course={academics.coursesTaught[1]} icon={ShieldCheck} color="#0ea5e9" />
                        <CourseCard course={academics.coursesTaught[2]} icon={Cpu} color="#10b981" />
                        <CourseCard course={academics.coursesTaught[3]} icon={Code} color="#f59e0b" />
                    </div>
                </section>

                {/* ---------- ACADEMIC AFFILIATIONS ---------- */}
                <section className="section-shell pb-24">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 px-2">
                        <SectionHeader title="Academic Affiliations" subtitle="Active membership in global scholarly organizations and professional bodies." centered={false} />
                    </div>
                    <div className="flex flex-wrap gap-4 px-2">
                        {academics.affiliations.map((aff, idx) => (
                            <div key={idx} className="px-5 py-3 rounded-xl bg-white border border-slate-100 shadow-sm flex items-center gap-3.5 hover:shadow-md transition-all hover:-translate-y-0.5">
                                <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-[var(--accent)] shrink-0">
                                    <Certificate size={18} weight="duotone" />
                                </div>
                                <span className="text-[13.5px] font-bold text-slate-700 leading-tight">{aff}</span>
                            </div>
                        ))}
                    </div>
                </section>
            </div>
        </div>
    );
}